<?php

class UserControlAppModel extends AppModel {
	
}