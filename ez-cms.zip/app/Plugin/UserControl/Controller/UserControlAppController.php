<?php

class UserControlAppController extends AppController { }

