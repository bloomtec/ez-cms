<?php 
$out = "\n\tpublic function beforeSave(){\n";
$out .= "\n\t}\n";
echo $out;
?>
