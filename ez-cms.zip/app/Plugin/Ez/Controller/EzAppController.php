<?php

class EzAppController extends AppController { }

