<?php

class EzAppModel extends AppModel {

}

