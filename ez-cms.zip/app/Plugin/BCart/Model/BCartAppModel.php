<?php

class BCartAppModel extends AppModel {

}

