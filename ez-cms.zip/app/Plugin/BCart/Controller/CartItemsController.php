<?php
App::uses('BCartAppController', 'BCart.Controller');
/**
 * CartItems Controller
 *
 */
class CartItemsController extends BCartAppController { }
